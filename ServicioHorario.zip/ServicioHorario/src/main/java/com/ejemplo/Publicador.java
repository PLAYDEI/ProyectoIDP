package com.ejemplo;

import javax.xml.ws.Endpoint;

public class Publicador {
    public static void main(String[] args) {
        Endpoint.publish("http://localhost:8080/ServicioHorario", new ServicioHorario());
        System.out.println("Servicio SOAP publicado en http://localhost:8080/ServicioHorario");
    }
}
