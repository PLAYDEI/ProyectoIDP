package com.ejemplo;

import javax.jws.WebMethod;
import javax.jws.WebService;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@WebService
public class ServicioHorario {

    @WebMethod
    public String getFecha() {
        return "La fecha actual es: " + LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
    }

    @WebMethod
    public String saludar(String nombre) {
        return "Hola, " + nombre + "! Bienvenido al servicio.";
    }
}
